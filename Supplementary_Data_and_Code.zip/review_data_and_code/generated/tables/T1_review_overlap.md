**Table 1. Position relative to closely related reviews. Locators refer to the supplied PDFs.**

| Review | Established coverage | Resolution added here |
| --- | --- | --- |
| [@S001], pp. 4–24 | Dual interpretation, stabilization, pricing rules and integer completion | Method-level link between traditional protection, learned action and measured scope |
| [@S014], pp. 30–33; linked erratum [@S014_errata] | Pricing schedules, pool management, branching and active cuts | Current learning variants and explicit recovery/certificate coding |
| [@S003], pp. 6–20 | Exact routing pricing, relaxations, cuts, branching and enumeration | Cross-application comparison with learned controllers and scoped experiments |
| [@S002], pp. 25–45 | BPC implementation, dominance, ng-routes and valid node bounds | Study-level coding and comparison of empirical claims |
| [@S004], pp. 16, 21–26 | Learned routing components, column/arc selection, branching, cost and generalization | Finer CG interface and guarantee conditions across application domains |
| [@S005], pp. 15–18, 25 | Column selection versus generation, AI across optimization, learning cost | Joint six-layer, guarantee and E0–E4 account for individual variants |
