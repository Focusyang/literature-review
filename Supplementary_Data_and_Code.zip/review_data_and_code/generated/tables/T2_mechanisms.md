**Table 2. Traditional and learned actions at the same computational interface.**

| Layer and decision | Traditional basis | Learned action | Main condition or cost |
| --- | --- | --- | --- |
| L1 Branch or open node | Pseudocosts, strong branching, node rules | Predict scores or allocate candidate-evaluation effort [@S049; @S062] | Valid disjunctions and retained nodes; scoring overhead |
| L2 Master and dual | Warm starts, smoothing, penalties, dual inequalities | Predict a reference or stabilization parameter [@S056; @S063; @S075] | Recover original LP conditions; cost per induced pricing call |
| L3 Pricing schedule | Partial pricing, pools, oracle cascades | Rank blocks or select a routine [@S058; @S060; @S091] | All required blocks certified at closure; variable call costs |
| L4 Domain and state | Dominance, completion bounds, resource relaxation | Propose graph/state restriction or feasibility test [@S052; @S055; @S064] | Safe proof or complete restoration; false rejection and recovery |
| L5 Search and construction | Bidirectional labeling, buckets, constructive heuristics | Order labels or generate feasible columns [@S053; @S065; @S088] | Retain necessary states or exact fallback; inference cost |
| L6 Existing columns | Batching, cleanup, pools and certified fixing | Score admission, retention or batch size [@S050; @S057; @S059] | Regeneration and progress guard; master/pricing tradeoff |
