**Table 3. Representative guarantee conditions. Labels apply to the stated variant, not automatically to every stage of a paper.**

| Variant and label | What supports the guarantee | Boundary |
| --- | --- | --- |
| Learned pricing order, G1 [@S058; @S091] | Retain complete block list and certify all relevant subproblems at closure | Earlier successful or stale calls do not close the current node |
| Graph restriction with restoration, G2 [@S055] | Final pricing on the complete graph | Guarantee is for the modeled route relaxation; restoration time counts |
| Learned construction, G2 [@S053; @S088] | Check feasibility and reduced cost; complete oracle after proposal failure | Restricted or capped fallback does not give the same guarantee |
| Partial dominance and fixing, G3 [@S031; @S045] | Proved continuation coverage or valid lower-bound plus incumbent test | Resources, active cuts and branching must satisfy the proof conditions |
| Learned dual restrictions, G4 [@S066] | Exact pricing for the weakened bound; separate artificial-variable recovery for baseline LP | Preprint; direct and recovered bounds are different targets |
| Exact and approximate loading dominance [@S052] | Feasibility verification plus exact dominance variant | Neural packing checks do not repair an approximate dominance rule |
| Permanent learned graph restriction, G5 [@S069] | Useful feasible columns may be generated | No full-domain certificate; known-optimum matches are not proofs |
| Insufficient certificate detail, GU [@S100] | Main paper describes heuristic/MIP pricing and an additional early certificate | Accessed certificate argument does not settle all stated conditions |
