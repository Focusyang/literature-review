**Table 5. Conditional choices and experiments that could resolve the remaining uncertainty.**

| Observed bottleneck | Candidate decision | Required comparison and protection | Failure to measure |
| --- | --- | --- | --- |
| Master time dominates | L6 admission or L2 stabilization | Match multi-column budgets; retain recovery and progress [@S050; @S057] | Smaller master causes more expensive pricing rounds |
| Many unequal pricing blocks | L3 cost-aware ranking | Random and adaptive heuristic schedules; certify every required block [@S058; @S091] | Fewer calls concentrate on harder or redundant subproblems |
| Large labeling frontier | L4 safe reduction or L5 ordering | Strong dominance/bucket baseline; retain completeness [@S019; @S031; @S065] | Inference or extra comparisons exceed saved extensions |
| Frequent failed cheap pricing | Adaptive switch to certification | Fixed cascades and deterministic switching; final valid oracle [@S055; @S088] | Training data omit failure and late-iteration states |
| Expensive branching scores | L1 staged candidate evaluation | Same candidates, incumbents and cuts; complete disjunctions [@S049; @S062] | Scoring savings increase tree size or node difficulty |
| Repeated related operational cases | Learned warm starts or reusable structure | Count training and transfer costs; evaluate new parent families [@S071; @S079; @S081] | Persistent topology changes make historical predictions misleading |
