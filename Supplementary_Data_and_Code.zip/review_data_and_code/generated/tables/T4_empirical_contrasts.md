**Table 4. Selected within-study contrasts. Times are seconds; rows are not comparable effect estimates.**

| Study and scope | Comparison and population | Reported observation | Interpretation boundary |
| --- | --- | --- | --- |
| [@S057], E2 | RL five-column selection versus Diverse-M; 1000/200/100 cutting-stock instances | Test-set totals 67.84/55.05/87.95 versus 74.59/59.32/93.60 | Online selection included; totals are not mean instance times; no tree result |
| [@S058], E4 | Learned versus random pricing-problem order, k=1; 9 five-day operating-room instances | Mean calls 2950 versus 3923; mean time 2087 versus 1916 | All nine solved; fewer calls but longer time; four-hour limit |
| [@S059], E2 | FFCG versus one-column and all-ten greedy; VRPTW sample size absent from accessed main paper | 426.99 versus 2662.07 and 511.97 | Inference included; sample details require missing appendix; comparator changes gain |
| [@S065], E1; preprint | Learned versus Node ordering; 17 easy, 12 medium, 9 hard cases | At k=10, easy group mean 24.9% slower; medium 8.8% faster; hard about 20% faster | All 38 solved; online learning included. Easy: baseline mean iteration <4 s; hard: baseline total >30 min |
| [@S066], E2; preprint | Direct/recovered inequalities versus default CG; 200 paired 500-customer CVRP instances | Geometric means 12.3/54.2 versus 119.9; mean bound loss 1.3%/0% | Headline timing excludes prediction/postprocessing; recovered bound checked |
| [@S045], E4 | Two-arc versus single-arc fixing; 459 success-conditioned cases from 840 | About 19% whole-BPC time reduction; 459 versus 455 proofs in selected set | New-method timeouts excluded; asymmetric limits; VRPTW given known optimum+1 |
| [@S069], E2 | Learned restriction versus same CG without it; 504 low-density routing instances | Mean times 448.20 versus 536.04; baseline-relative reduction 16.39% (calculated) | One-hour limit; heuristic closure; paper uses 19.60% with another denominator |
| [@S091], E2/E4; preprint | Fixed-row replay and complete-tree tests on disjoint parent families | 45 matched states in 29 families; tree subset 18 of 30 jointly complete | Tree reductions concern calls/master solves; detailed full-policy outcomes unavailable |
| [@S102], E2 | CSDW-S selective versus CSDW-X exact-all; 24 primary paired root conditions | Accepted endpoints 15/24 versus 24/24; fewer exact calls in all 15 jointly accepted pairs, but slower in 14 | Median paired time difference +20.72; 600 s task deadline; separate historical and complete-sweep campaigns excluded |
| [@S103], E1; preprint | PLA versus author-implemented pulse; all 81 type-2 path instances, five bucket settings | Mean total times 91.579 versus 105.492; 61/81 versus 57/81 solved | 300 s overall cap; preprocessing included; success and timeout aggregation across settings not fully specified; no CG or tree result |

Note. VRPTW denotes the vehicle routing problem with time windows. Other abbreviations are defined in the text.
