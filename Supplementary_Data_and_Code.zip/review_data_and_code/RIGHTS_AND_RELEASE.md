# Rights and release status

Version 1.2 is prepared for public release at https://github.com/Focusyang/literature-review with the author's authorization. Creator: Xinran Yang, School of Management and Engineering, Capital University of Economics and Business, China. Repository history, rather than this preparation statement, records any completed upload or release.

No data or software reuse license has been authorized, and no DOI or archival persistent identifier has been assigned in this package. Public accessibility alone does not grant an open reuse license. No LICENSE file is supplied. A repository may use separate data and software licenses if the author later authorizes them; no particular license is assumed here.

The package consists of review-generated classifications, paraphrased evidence summaries, source locators, manuscript-claim mappings and computational summary code. Bibliographic titles, author lists, identifiers and source links identify third-party publications. Those publications retain their own rights and access conditions. Downloaded PDFs, publisher abstracts, extracted full text, source-page images and raw response dumps are excluded. No right to redistribute the original papers is granted by this package.

The author must verify the rights needed before choosing reuse terms and review any funding or institutional conditions. If an archival identifier, actual release date or license is later assigned, update metadata.json and the repository record consistently. Add an article or preprint link only when its real identifier exists. No claim of complete FAIR compliance is made while archival identification and licensing remain unresolved.

This package contains no author email or other direct contact field. The public creator name and affiliation identify the dataset author. Paper-author names in bibliographic records provide scholarly attribution.
