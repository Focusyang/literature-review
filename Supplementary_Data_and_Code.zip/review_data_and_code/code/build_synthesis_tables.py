import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'generated'/'tables';OUT.mkdir(parents=True,exist_ok=True)
def table(name,caption,headers,rows):
    with (OUT/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(headers);w.writerows(rows)
    text='**'+caption+'**\n\n| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'
    text+='\n'.join('| '+' | '.join(str(v).replace('|',' / ') for v in r)+' |' for r in rows)+'\n'
    (OUT/(name+'.md')).write_text(text)

table('T1_review_overlap','Table 1. Position relative to closely related reviews. Locators refer to the supplied PDFs.',
['Review','Established coverage','Resolution added here'],[
['[@S001], pp. 4–24','Dual interpretation, stabilization, pricing rules and integer completion','Method-level link between traditional protection, learned action and measured scope'],
['[@S014], pp. 30–33; linked erratum [@S014_errata]','Pricing schedules, pool management, branching and active cuts','Current learning variants and explicit recovery/certificate coding'],
['[@S003], pp. 6–20','Exact routing pricing, relaxations, cuts, branching and enumeration','Cross-application comparison with learned controllers and scoped experiments'],
['[@S002], pp. 25–45','BPC implementation, dominance, ng-routes and valid node bounds','Study-level coding and comparison of empirical claims'],
['[@S004], pp. 16, 21–26','Learned routing components, column/arc selection, branching, cost and generalization','Finer CG interface and guarantee conditions across application domains'],
['[@S005], pp. 15–18, 25','Column selection versus generation, AI across optimization, learning cost','Joint six-layer, guarantee and E0–E4 account for individual variants']])

table('T2_mechanisms','Table 2. Traditional and learned actions at the same computational interface.',
['Layer and decision','Traditional basis','Learned action','Main condition or cost'],[
['L1 Branch or open node','Pseudocosts, strong branching, node rules','Predict scores or allocate candidate-evaluation effort [@S049; @S062]','Valid disjunctions and retained nodes; scoring overhead'],
['L2 Master and dual','Warm starts, smoothing, penalties, dual inequalities','Predict a reference or stabilization parameter [@S056; @S063; @S075]','Recover original LP conditions; cost per induced pricing call'],
['L3 Pricing schedule','Partial pricing, pools, oracle cascades','Rank blocks or select a routine [@S058; @S060; @S091]','All required blocks certified at closure; variable call costs'],
['L4 Domain and state','Dominance, completion bounds, resource relaxation','Propose graph/state restriction or feasibility test [@S052; @S055; @S064]','Safe proof or complete restoration; false rejection and recovery'],
['L5 Search and construction','Bidirectional labeling, buckets, constructive heuristics','Order labels or generate feasible columns [@S053; @S065; @S088]','Retain necessary states or exact fallback; inference cost'],
['L6 Existing columns','Batching, cleanup, pools and certified fixing','Score admission, retention or batch size [@S050; @S057; @S059]','Regeneration and progress guard; master/pricing tradeoff']])

table('T3_guarantees','Table 3. Representative guarantee conditions. Labels apply to the stated variant, not automatically to every stage of a paper.',
['Variant and label','What supports the guarantee','Boundary'],[
['Learned pricing order, G1 [@S058; @S091]','Retain complete block list and certify all relevant subproblems at closure','Earlier successful or stale calls do not close the current node'],
['Graph restriction with restoration, G2 [@S055]','Final pricing on the complete graph','Guarantee is for the modeled route relaxation; restoration time counts'],
['Learned construction, G2 [@S053; @S088]','Check feasibility and reduced cost; complete oracle after proposal failure','Restricted or capped fallback does not give the same guarantee'],
['Partial dominance and fixing, G3 [@S031; @S045]','Proved continuation coverage or valid lower-bound plus incumbent test','Resources, active cuts and branching must satisfy the proof conditions'],
['Learned dual restrictions, G4 [@S066]','Exact pricing for the weakened bound; separate artificial-variable recovery for baseline LP','Preprint; direct and recovered bounds are different targets'],
['Exact and approximate loading dominance [@S052]','Feasibility verification plus exact dominance variant','Neural packing checks do not repair an approximate dominance rule'],
['Permanent learned graph restriction, G5 [@S069]','Useful feasible columns may be generated','No full-domain certificate; known-optimum matches are not proofs'],
['Insufficient certificate detail, GU [@S100]','Main paper describes heuristic/MIP pricing and an additional early certificate','Accessed certificate argument does not settle all stated conditions']])

table('T4_empirical_contrasts','Table 4. Selected within-study contrasts. Times are seconds; rows are not comparable effect estimates.',
['Study and scope','Comparison and population','Reported observation','Interpretation boundary'],[
['[@S057], E2','RL five-column selection versus Diverse-M; 1000/200/100 cutting-stock instances','Test-set totals 67.84/55.05/87.95 versus 74.59/59.32/93.60','Online selection included; totals are not mean instance times; no tree result'],
['[@S058], E4','Learned versus random pricing-problem order, k=1; 9 five-day operating-room instances','Mean calls 2950 versus 3923; mean time 2087 versus 1916','All nine solved; fewer calls but longer time; four-hour limit'],
['[@S059], E2','FFCG versus one-column and all-ten greedy; VRPTW sample size absent from accessed main paper','426.99 versus 2662.07 and 511.97','Inference included; sample details require missing appendix; comparator changes gain'],
['[@S065], E1; preprint','Learned versus Node ordering; 17 easy, 12 medium, 9 hard cases','At k=10, easy group mean 24.9% slower; medium 8.8% faster; hard about 20% faster','All 38 solved; online learning included. Easy: baseline mean iteration <4 s; hard: baseline total >30 min'],
['[@S066], E2; preprint','Direct/recovered inequalities versus default CG; 200 paired 500-customer CVRP instances','Geometric means 12.3/54.2 versus 119.9; mean bound loss 1.3%/0%','Headline timing excludes prediction/postprocessing; recovered bound checked'],
['[@S045], E4','Two-arc versus single-arc fixing; 459 success-conditioned cases from 840','About 19% whole-BPC time reduction; 459 versus 455 proofs in selected set','New-method timeouts excluded; asymmetric limits; VRPTW given known optimum+1'],
['[@S069], E2','Learned restriction versus same CG without it; 504 low-density routing instances','Mean times 448.20 versus 536.04; baseline-relative reduction 16.39% (calculated)','One-hour limit; heuristic closure; paper uses 19.60% with another denominator'],
['[@S091], E2/E4; preprint','Fixed-row replay and complete-tree tests on disjoint parent families','45 matched states in 29 families; tree subset 18 of 30 jointly complete','Tree reductions concern calls/master solves; detailed full-policy outcomes unavailable'],
['[@S102], E2','CSDW-S selective versus CSDW-X exact-all; 24 primary paired root conditions','Accepted endpoints 15/24 versus 24/24; fewer exact calls in all 15 jointly accepted pairs, but slower in 14','Median paired time difference +20.72; 600 s task deadline; separate historical and complete-sweep campaigns excluded'],
['[@S103], E1; preprint','PLA versus author-implemented pulse; all 81 type-2 path instances, five bucket settings','Mean total times 91.579 versus 105.492; 61/81 versus 57/81 solved','300 s overall cap; preprocessing included; success and timeout aggregation across settings not fully specified; no CG or tree result']])

table('T5_conditional_choices','Table 5. Conditional choices and experiments that could resolve the remaining uncertainty.',
['Observed bottleneck','Candidate decision','Required comparison and protection','Failure to measure'],[
['Master time dominates','L6 admission or L2 stabilization','Match multi-column budgets; retain recovery and progress [@S050; @S057]','Smaller master causes more expensive pricing rounds'],
['Many unequal pricing blocks','L3 cost-aware ranking','Random and adaptive heuristic schedules; certify every required block [@S058; @S091]','Fewer calls concentrate on harder or redundant subproblems'],
['Large labeling frontier','L4 safe reduction or L5 ordering','Strong dominance/bucket baseline; retain completeness [@S019; @S031; @S065]','Inference or extra comparisons exceed saved extensions'],
['Frequent failed cheap pricing','Adaptive switch to certification','Fixed cascades and deterministic switching; final valid oracle [@S055; @S088]','Training data omit failure and late-iteration states'],
['Expensive branching scores','L1 staged candidate evaluation','Same candidates, incumbents and cuts; complete disjunctions [@S049; @S062]','Scoring savings increase tree size or node difficulty'],
['Repeated related operational cases','Learned warm starts or reusable structure','Count training and transfer costs; evaluate new parent families [@S071; @S079; @S081]','Persistent topology changes make historical predictions misleading']])
print('Five tables exported as CSV and Markdown')

with (OUT/'T4_empirical_contrasts.md').open('a') as f:
    f.write('\nNote. VRPTW denotes the vehicle routing problem with time windows. Other abbreviations are defined in the text.\n')
