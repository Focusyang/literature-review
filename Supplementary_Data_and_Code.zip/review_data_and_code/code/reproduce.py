"""Validate the saved review dataset and regenerate its mechanical summaries.
Run from any working directory: python /path/to/package/code/reproduce.py [--figures]
No internet access or original-paper files are used.
"""
from pathlib import Path
from collections import Counter, defaultdict
import argparse, csv, hashlib, json, subprocess, sys
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'generated'

def read(name):
    with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def write(name,rows,fields=None):
    p=ROOT/name; p.parent.mkdir(parents=True,exist_ok=True)
    fields=fields or list(dict.fromkeys(k for x in rows for k in x))
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def ids(rows,key):return '|'.join(x[key] for x in rows)
def tokens(value):return [x for x in value.split('|') if x]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figures',action='store_true',help='Also render three SVG diagrams; requires Matplotlib.')
    args=parser.parse_args()
    tables={n:read('data/'+n+'.csv') for n in ['studies','methods','evidence','claims','records','screening','reading_coverage','actual_version_relations','read_reports']}
    s,m,e,c,r=tables['studies'],tables['methods'],tables['evidence'],tables['claims'],tables['records']
    counts=json.loads((ROOT/'data/counts.json').read_text())
    checks=[]
    def check(name,ok,detail):checks.append({'check':name,'status':'PASS' if ok else 'FAIL','detail':detail})
    indexes={n:{x[k]:x for x in tables[n]} for n,k in [('studies','study_id'),('methods','method_id'),('evidence','evidence_id'),('claims','claim_id'),('records','record_id')]}
    check('unique identifiers',all(len(indexes[n])==len(tables[n]) for n in indexes),{n:len(v) for n,v in indexes.items()})
    check('snapshot row counts',len(s)==counts['included_families'] and len(m)==counts['all_method_rows'] and len(e)==counts['fulltext_evidence_rows'] and len(c)==78,{'studies':len(s),'methods':len(m),'evidence':len(e),'claims':len(c)})
    check('study collections',dict(Counter(x['collection'] for x in s))==counts['collections'],dict(Counter(x['collection'] for x in s)))
    check('evidence links',all(x['study_id'] in indexes['studies'] and x['method_id'] in indexes['methods'] and x['record_id'] in indexes['records'] and indexes['methods'][x['method_id']]['study_id']==x['study_id'] for x in e),'Every evidence row joins its family, method and actual reading record')
    check('claim links',all(i in indexes['evidence'] for x in c for key in ['supporting_evidence_ids','counter_evidence_ids'] for i in tokens(x[key])),'Supporting and counter-evidence identifiers resolve; this is not a new substantive claim audit')
    check('method reading-version links',all(x['actual_read_record_id'] in indexes['records'] for x in m),'Actual version IDs resolve separately from preferred bibliographic records')
    eligible=[x for x in m if x['collection'] in ['CORE','SUPPORT']]
    check('primary coding domains',len(eligible)==138 and all(x['main_layer'] in ['L1','L2','L3','L4','L5','L6'] and x['guarantee'] in ['G1','G2','G3','G4','G5','GU'] and set(tokens(x['empirical_scope']))<=set(['E0','E1','E2','E3','E4','NA']) for x in eligible),'138 CORE/SUPPORT variants; background excluded')
    kept=[x for x in tables['reading_coverage'] if x['inclusion_decision']!='EXCLUDED']
    check('retained main-paper reading coverage',len(kept)==99 and all(x['full_main_read']=='True' and set(tokens(x['pages_read']))=={str(i) for i in range(1,int(x['pages_total'])+1)} for x in kept),{'retained_main_pages':sum(int(x['pages_total']) for x in kept),'expected':counts['main_pages_fully_read']})
    check('screened family denominator',len(tables['screening'])==103 and Counter(x['decision'] for x in tables['screening'])['EXCLUDED']==4,'103 assessed families, 99 retained; erratum not a separate family')
    leads=read('search/additional_lead_dispositions.csv')
    expected_leads={'NOT_SELECTED_FOR_CRITICAL_SAMPLE':74,'FULLTEXT_READ_INCLUDED':3,'EXCLUDED':1,'EARLIER_REPORT_OF_INCLUDED_FAMILY':1}
    check('additional lead dispositions',dict(Counter(x['screen_status'] for x in leads))==expected_leads,dict(Counter(x['screen_status'] for x in leads)))
    triage=read('search/crossref_title_triage.csv')
    check('Crossref export units',len(triage)==180 and len({x['doi'].lower() for x in triage})==170,'180 returned rows, 170 unique DOIs; not the full-text assessment denominator')
    check('search event count',len(read('search/search_log.csv'))==counts['search_log_batches'],'186 heterogeneous query/access operations; result totals are not pooled')
    si,mi,ri=indexes['studies'],indexes['methods'],indexes['records']
    ci={x['study_id']:x for x in tables['reading_coverage']};by_s=defaultdict(list);by_m=defaultdict(list)
    for x in e:by_s[x['study_id']].append(x);by_m[x['method_id']].append(x)
    s1=[];s2=[];s3=[];s4=[]
    for x in s:
        sid=x['study_id'];pref='R'+sid[1:];record=ri[pref];cov=ci[sid]
        y=dict(x,preferred_record_id=pref)
        for k in ['title','authors','year_online','year_issue','venue','volume_issue_pages','doi','repository_id','publication_status','primary_url']:y[k]=record[k]
        for k in ['actual_version','reading_status','full_main_read','pages_total','pages_read']:y[k]=cov[k]
        y.update(fulltext_sha256=cov['sha256'],reading_limitations=cov['limitations'],linked_method_ids=ids([a for a in m if a['study_id']==sid],'method_id'),linked_evidence_ids=ids(by_s[sid],'evidence_id'),publication_record_ids=ids([a for a in r if a['study_id']==sid],'record_id'))
        s1.append(y)
    for x in m:
        sid=x['study_id'];mid=x['method_id'];direct=by_m[mid];context=by_s[sid]
        y=dict(x,title=ri['R'+sid[1:]]['title'],actual_version=ci[sid]['actual_version'],counted_in_core_support_method_distribution=str(x['collection'] in ['CORE','SUPPORT']),direct_method_evidence_ids=ids(direct,'evidence_id'),study_evidence_ids=ids(context,'evidence_id'))
        s2.append(y)
        selected=['study_id','method_id','variant','collection','primary_variant','main_layer','secondary_layers','guarantee','guarantee_secondary','guarantee_notes','recovery_or_certificate','exactness_basis','boundary','secondary_notes','empirical_scope','empirical_scope_notes','limitations','verification','actual_read_record_id','title','actual_version','counted_in_core_support_method_distribution','direct_method_evidence_ids','study_evidence_ids']
        z={k:v for k,v in y.items() if k in selected}
        z.update(audit_linkage_mode='DIRECT_METHOD_EVIDENCE' if direct else 'STUDY_CONTEXT_WITH_VARIANT_CONDITIONS_ONLY',direct_method_evidence_count=len(direct),study_evidence_count=len(context),audit_status='EXPORTED_SOURCE_CONDITIONS;NOT_A_NEW_PROOF')
        s3.append(z)
    for x in e:
        sid=x['study_id'];method=mi[x['method_id']]
        s4.append(dict(x,study_collection=si[sid]['collection'],study_title=ri['R'+sid[1:]]['title'],method_variant=method['variant'],method_main_layer=method['main_layer'],method_guarantee=method['guarantee'],method_guarantee_notes=method.get('guarantee_notes',''),method_recovery_or_certificate=method['recovery_or_certificate'],ledger_scope='ALL_EVIDENCE_TYPES;FILTER_PROVENANCE_FOR_EMPIRICAL_ROWS'))
    for name,rows in [('Table_S1_study_inventory.csv',s1),('Table_S2_method_inventory.csv',s2),('Table_S3_guarantee_audit.csv',s3),('Table_S4_empirical_evidence.csv',s4)]:write('generated/supplementary/'+name,rows)
    check('variant linkage transparency',sum(not by_m[x['method_id']] for x in m)==29,'29 variants use explicitly labeled study context, not invented direct proof')
    cells=Counter();members=defaultdict(list)
    for x in eligible:
        for scope in tokens(x['empirical_scope']):
            if scope in ['E0','E1','E2','E3','E4']:cells[x['guarantee'],scope]+=1;members[x['guarantee'],scope].append(x['method_id'])
    matrix=[{'guarantee':g,'scope':scope,'n_method_variants':cells[g,scope],'method_ids':'|'.join(members[g,scope])} for g in ['G1','G2','G3','G4','G5','GU'] for scope in ['E0','E1','E2','E3','E4']]
    write('generated/figures/F3_matrix_data.csv',matrix)
    expected=read('data/expected_F3_matrix_data.csv')
    check('Figure 3 source agreement',all(a['guarantee']==b['guarantee'] and a['scope']==b['scope'] and str(a['n_method_variants'])==b['n_method_variants'] and a['method_ids']==b['method_ids'] for a,b in zip(matrix,expected)) and len(expected)==30,'All 30 cells and member IDs match the saved manuscript source; multiple E scopes are not additive')
    subprocess.run([sys.executable,str(ROOT/'code/build_synthesis_tables.py')],check=True)
    if args.figures:subprocess.run([sys.executable,str(ROOT/'code/build_figures.py')],check=True)
    report={'package_version':'1.2','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'scope':'Validation and regeneration of saved review records only; no solver experiments or live searches rerun','figure_rendering_requested':args.figures}
    (ROOT/'validation').mkdir(exist_ok=True)
    (ROOT/'validation/validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(report['status'],len(checks),'checks')
    if report['status']!='PASS':
        for x in checks:
            if x['status']=='FAIL':print(x)
        raise SystemExit(1)
if __name__=='__main__':main()
