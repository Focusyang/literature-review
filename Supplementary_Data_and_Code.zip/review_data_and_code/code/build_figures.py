from pathlib import Path
import sys,os,json,csv,collections
ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':9,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.dpi':600})
OUT=ROOT/'generated'/'figures';OUT.mkdir(parents=True,exist_ok=True)
counts=json.load((ROOT/'data/counts.json').open())
methods=list(csv.DictReader((ROOT/'data/methods.csv').open(encoding='utf-8-sig')))
def canvas(height):
    fig,ax=plt.subplots(figsize=(7.204724,height/25.4));fig.subplots_adjust(left=.015,right=.985,bottom=.02,top=.98)
    ax.set_xlim(0,100);ax.set_ylim(0,100);ax.axis('off');return fig,ax
def box(ax,x,y,w,h,title,sub='',fill='#EDF3F6',size=9):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.2,rounding_size=1.1',linewidth=.7,edgecolor='#6C7A86',facecolor=fill))
    ax.text(x+w/2,y+h*.65 if sub else y+h*.5,title,ha='center',va='center',fontsize=size,fontweight='bold',linespacing=1.25)
    if sub:ax.text(x+w/2,y+h*.28,sub,ha='center',va='center',fontsize=8,linespacing=1.25)
def arrow(ax,a,b,**kw):ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','lw':1,'color':'#34495E',**kw})
def save(fig,name):
    fig.canvas.draw()
    fig.savefig(OUT/f'{name}.svg')
    plt.close(fig)

fig,ax=canvas(164)
box(ax,19,86,64,12,'L1  Tree control','Branching decisions and open-node order')
box(ax,19,70,64,12,'L2  Master and duals','Warm starts, stabilization and dual selection')
box(ax,19,54,64,12,'L3  Pricing orchestration','Choose the next subproblem or pricing routine')
box(ax,19,38,64,12,'L4  Pricing domain and state','Restrictions, relaxations, dominance and bounds')
box(ax,19,22,64,12,'L5  Search and construction','Order internal work or construct a candidate column')
box(ax,19,6,64,12,'L6  Generated-column management','Admission, pools, retention and deletion')
for y in [86,70,54,38,22]:arrow(ax,(51,y),(51,y-4))
ax.plot([19,9,9,19],[12,12,76,76],color='#34495E',lw=1)
arrow(ax,(9,76),(19,76))
ax.text(5,44,'Admitted columns',ha='center',va='center',rotation=90,rotation_mode='anchor',fontsize=8)
ax.plot([83,92,92,83],[28,28,92,92],color='#34495E',lw=1)
arrow(ax,(92,92),(83,92))
ax.text(96,60,'Valid closure or bound required',ha='center',va='center',rotation=90,rotation_mode='anchor',fontsize=8)
save(fig,'F1_intervention_layers')

fig,ax=canvas(164)
ax.text(2,98,'Supplied full-text assessment frame',fontsize=10,fontweight='bold',va='top')
box(ax,7,80,86,12,f"{counts['supplied_reports']} supplied PDF reports",f"{counts['candidate_families']} candidate families; one linked erratum")
arrow(ax,(50,80),(50,75))
box(ax,7,62,86,13,f"{counts['candidate_families']} families assessed for eligibility",'4 adjacent general surveys excluded on scope')
arrow(ax,(50,62),(50,57))
c=counts['collections']
box(ax,7,44,86,13,f"{counts['included_families']} retained families with complete main-paper reading",f"{c.get('CORE',0)} core  |  {c.get('SUPPORT',0)} supporting  |  {c.get('BACKGROUND',0)} background")
ax.text(2,35,'Separate Crossref diagnostic export',fontsize=10,fontweight='bold',va='top')
ax.text(7,28,'180 exported rows; 170 unique DOIs',fontsize=9,va='center')
ax.text(7,20,'52 title exclusions; 40 already represented or earlier-version DOIs',fontsize=8,va='center')
ax.text(7,13,'1 reverse-use exclusion; 3 newly read and included families',fontsize=8,va='center')
ax.text(7,6,'74 additional leads not selected for the critical sample',fontsize=8,va='center')
save(fig,'F2_assessment_flow')

labels=['G1  Order only','G2  Restriction and recovery','G3  Safe elimination','G4  Valid relaxation or stabilization','G5  Incomplete guarantee','GU  Insufficient evidence']
gcodes=['G1','G2','G3','G4','G5','GU'];ecodes=['E0','E1','E2','E3','E4']
cells=collections.Counter();members=collections.defaultdict(list)
eligible=[m for m in methods if m['collection'] in ['CORE','SUPPORT']]
for m in eligible:
    for e in m['empirical_scope'].split('|'):
        if e in ecodes:
            cells[m['guarantee'],e]+=1;members[m['guarantee'],e].append(m['method_id'])
with (OUT/'F3_matrix_data.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['guarantee','scope','n_method_variants','method_ids']);w.writeheader()
    for g in gcodes:
        for e in ecodes:w.writerow({'guarantee':g,'scope':e,'n_method_variants':cells[g,e],'method_ids':'|'.join(members[g,e])})
fig,ax=plt.subplots(figsize=(7.204724,112/25.4))
fig.subplots_adjust(left=.47,right=.97,bottom=.23,top=.91)
vals=[[cells[g,e] for e in ecodes] for g in gcodes]
im=ax.imshow(vals,cmap='Blues',vmin=0,vmax=max(max(row) for row in vals),aspect='auto')
ax.set_xticks(range(5),['E0\nOffline','E1\nPricing','E2\nCG / root','E3\nNonroot','E4\nFull tree'],fontsize=8)
ax.set_yticks(range(6),labels,fontsize=8)
ax.tick_params(length=0,pad=8)
for i,row in enumerate(vals):
    for j,v in enumerate(row):ax.text(j,i,str(v),ha='center',va='center',fontsize=10,color='white' if v>max(max(r) for r in vals)*.6 else '#14212B')
for spine in ax.spines.values():spine.set_visible(False)
fig.text(.02,.065,f"{len(eligible)} core/support variants. A variant may appear in several scope columns.",fontsize=8)
fig.text(.02,.02,'Counts describe the reviewed sample. Cells are not additive or quality scores.',fontsize=8)
save(fig,'F3_guarantee_evidence')
print('Saved three SVG figures and F3 source data')
