# Data and code for a critical review of column generation and branch-and-price acceleration

Version 1.2, prepared 12 October 2026 for public release at https://github.com/Focusyang/literature-review.

Creator: Xinran Yang, School of Management and Engineering, Capital University of Economics and Business, China.

The author has authorized release of these curated materials to the designated repository. No DOI or other archival persistent identifier is assigned in this package. No data or software reuse license has been authorized. Preparation of this version does not itself certify a completed upload; the repository history records any actual publication of its files.

## Contents and scope

The package supports the manuscript's comparison of six intervention layers, conditional guarantee labels and computational evidence scopes. It contains 99 retained study families (79 CORE, 8 SUPPORT, 12 BACKGROUND), 154 method rows, 505 extracted evidence items and 78 curated claims. The Figure 3 distribution uses 138 CORE/SUPPORT method variants and excludes 16 background rows. These counts describe a bounded critical sample, not the prevalence of methods in the whole literature.

The assessment frame contains 104 supplied reports representing 103 candidate families. Four families were excluded on scope. A linked erratum belongs to its original family. One separately accessed 19-page e-companion yields 105 report records in the report ledger; it is not an additional supplied PDF or an additional study. Complete reading covers 2,133 pages of retained main papers, plus the two-page erratum and that e-companion. Unaccessed external supplements remain explicitly identified.

This archive includes generated review records and bibliographic metadata. It excludes downloaded papers, extracted third-party full text, source-page screenshots, raw web-response dumps, the unpublished author draft, author contact information, document render caches and internal QA images. Source-paper identities and SHA-256 hashes are retained so that an authorized reader can distinguish the actual reading version from the preferred formal citation. Obtain original papers through their linked publishers or lawful repositories. No right to redistribute those papers is granted by this package.

## File map

| Path | Purpose |
|---|---|
| data/studies.csv | One row per retained family, with the main method's coding and variant count |
| data/methods.csv | All 154 method or framework variants; use this table for method distributions |
| data/evidence.csv | 505 source-located items, including theory, algorithm, empirical and other evidence |
| data/claims.csv | 78 curated manuscript claims with supporting evidence IDs, conditions and counter-evidence |
| data/records.csv | 119 bibliographic and actual-reading records; titles, authors, identifiers and version status |
| data/actual_version_relations.csv | 14 checked actual-read-version relationships |
| data/version_relations.csv | 74 discovery-stage candidate/reported version links; verification status must be retained |
| data/screening.csv | Eligibility decisions for 103 candidate families |
| data/reading_coverage.csv and read_reports.csv | Family and report coverage, versions, page numbers and source-file hashes without the files themselves |
| data/review_overlap.csv | Full-text-supported comparison with seven adjacent reviews |
| data/counts.json | Frozen sample and reporting denominators |
| data/expected_F3_matrix_data.csv | Saved Figure 3 cell counts and method memberships used for the regression check |
| search/search_log.csv | 186 heterogeneous discovery/access events; literal queries or requests, limits, dates, failures and available result counts |
| search/crossref_title_triage.csv | Initial dispositions for the 180-row, 170-unique-DOI diagnostic export |
| search/additional_lead_dispositions.csv | Later disposition of all 79 pending unique DOI leads, including three now-read additions |
| search/citation_chasing.csv | 41 selected backward title matches to already retained studies |
| search/reader_citation_leads.csv | 76 reading-note flags, explicitly not a claim of completed follow-up |
| methods/supplementary_methods.md | Current scope, acquisition, reading and synthesis methods adapted to this package's file map |
| methods/codebook.md and field_dictionary.csv | Coding definitions, missingness, units, field meanings and joins |
| methods/derivations.md | Exact summary operations and their limits |
| bibliography/references_all.bib | 100 records for the 99 retained families and linked erratum |
| bibliography/references_manuscript.bib | The 80 entries cited in the manuscript snapshot |
| code/ | Portable validation, table and figure scripts |
| generated/supplementary/ | Tables S1–S4 generated from the normalized data |
| generated/tables/ | Five curated manuscript comparison tables in CSV and Markdown |
| generated/figures/ | Three SVG diagrams and the Figure 3 source matrix |
| validation/validation_report.json | Latest local structural check results |
| provenance/source_snapshot.json | Source-file hashes and explicit export transformations |
| MANIFEST.sha256 | Integrity checksums for every distributed file except the manifest itself |

Tables S1–S4 are convenience views of the normalized data, not extra studies or independent evidence. S1 is the study inventory; S2 is the method inventory; S3 is the conditional-guarantee audit; S4 is the complete evidence ledger enriched with method context. Despite S4's historical filename, it contains all evidence types. Filter provenance_type when selecting empirical evidence. Twenty-nine method variants have no directly assigned evidence row; S3 explicitly marks study-context linkage and retains the variant's conditions. A shared family reference does not establish a new proof for every variant.

## Reproduce the saved summaries

Python 3.10 or later is required. The package was tested with Python 3.12. No absolute workspace path, local skill, source-paper PDF, commercial solver or internet connection is required for validation and table regeneration. From the extracted package directory run:

    python code/reproduce.py

This command uses only the Python standard library. It validates counts, identifiers, evidence and claim links, primary coding values, reading coverage and lead dispositions. It regenerates Tables S1–S4, the five comparison tables, and all 30 Figure 3 cells with their method IDs. A failure causes a nonzero exit status. The script can also be called by its absolute path from a different working directory.

To regenerate the SVG figures, create an environment and install the single plotting dependency:

    python -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    .venv/bin/python code/reproduce.py --figures

On Windows, the environment executable is .venv\Scripts\python.exe. Matplotlib 3.11.2 is pinned to the version used in this snapshot. Arial is preferred when available and DejaVu Sans is the fallback. Font availability and SVG metadata can change file bytes without changing counts. Figure 3's data and memberships, rather than image byte identity, are the reproducibility target. The command writes only within generated/, validation/ and an optional local .cache/ font cache. No manuscript or source data are overwritten.

The code does not reproduce the solvers, benchmarks, neural training or performance results of the original papers. It also does not repeat live searches, whose rankings can change. The five comparison tables are curated synthesis definitions, not outputs of a meta-analysis. The evidence ledger records source-reported results and clearly marked arithmetic interpretations. NR and NOT_ACCESSED are not converted into zero.

## Read the search chronology correctly

The Crossref discovery export is separate from the author-supplied full-text frame. Its 180 returned rows came from nine successful first-page requests of 20 records each; a tenth request failed. Initial title triage remains historical. The current 79-lead table contains 74 unselected leads, three fully read included families, one earlier report of an included family and one exclusion. Unselected does not mean ineligible. Queries are relevance-ranked query.bibliographic requests, not controlled Boolean searches. No Web of Science or Scopus search is claimed.

The unified log preserves event metadata and historical response-reference strings. original_export_reference and original_component_log identify artifacts in the author archive, not files included here. raw_response_included is explicitly NO. Publisher abstracts are omitted from the exported screening tables. The event records and bibliography permit tracing the queries and selected records; redistribution of complete raw responses is not claimed.

## Metadata, rights and citation

metadata.json records the confirmed creator and affiliation, package version, preparation date, selected repository and coverage. Its persistent-identifier and license fields are null because no DOI, archival identifier or reuse license has been assigned. RIGHTS_AND_RELEASE.md describes the rights boundary. No LICENSE file is supplied.

Cite the specific repository version or immutable commit that was actually accessed. The target journal's supplied guide asks for dataset author(s), title, repository, version, year and global persistent identifier, with a [dataset] tag in the reference. An archival identifier must only be added if one is actually assigned. The dataset's preparation date is not presented as a verified upload date, and a GitHub URL is not a DOI.

The journal-facing supplementary files are Supplementary Methods (the separate editable DOCX) and Supplementary Data and Code (this ZIP). The author submission document, title page, captions and full internal working package are not part of this repository package.
